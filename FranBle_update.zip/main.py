"""
Ventana principal del cliente FranBle — PyQt6
"""

import asyncio
import logging
import sys
import time
from typing import Optional

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QByteArray
from PyQt6.QtGui import QFont, QIcon, QPixmap, QColor, QKeySequence, QShortcut
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QTreeWidget, QTreeWidgetItem, QTextEdit, QLineEdit,
    QPushButton, QLabel, QStatusBar, QMenuBar, QMenu, QDialog,
    QFormLayout, QDialogButtonBox, QCheckBox, QComboBox, QSlider,
    QGroupBox, QFrame, QScrollArea, QSizePolicy, QMessageBox,
)

from transport import ServerConnection
from audio import AudioCapture, AudioPlayback
from video import VideoManager, VideoWidget
from config import config
from settings_dialog import SettingsDialog
from protocol import (
    MSG_AUTH_OK, MSG_AUTH_FAIL, MSG_ROOM_LIST, MSG_USER_LIST,
    MSG_USER_JOIN, MSG_USER_LEAVE, MSG_CHAT,
    MSG_STREAM_START, MSG_STREAM_STOP,
    MSG_STREAM_LOCKED, MSG_ERROR, MSG_PONG,
    MSG_P2P_ENDPOINT,
)

log = logging.getLogger("ui")

APP_NAME    = "FranBle"
APP_VERSION = "1.0.0"


# ──────────────────────────────────────────────
# Hilo de asyncio en background
# ──────────────────────────────────────────────

class AsyncThread(QThread):
    """Corre el event loop de asyncio en un hilo separado."""

    def __init__(self):
        super().__init__()
        self.loop: Optional[asyncio.AbstractEventLoop] = None

    def run(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def submit(self, coro):
        """Agenda una corrutina desde el hilo Qt."""
        if self.loop:
            return asyncio.run_coroutine_threadsafe(coro, self.loop)

    def stop(self):
        if self.loop:
            self.loop.call_soon_threadsafe(self.loop.stop)


# ──────────────────────────────────────────────
# Selector de fuente de pantalla
# ──────────────────────────────────────────────

class ScreenPickerDialog(QDialog):
    """
    Dialogo para elegir cómo compartir la pantalla:
      • Pantalla completa
      • Ventana de aplicacion
      • Region personalizada
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Compartir pantalla")
        self.setFixedSize(480, 420)

        self.result_choice  = "screen"   # "screen" | "window" | "region"
        self.result_quality = "1080p"
        self.result_window  = None       # dict con info de la ventana elegida

        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        # ── Calidad ───────────────────────────────
        quality_row = QHBoxLayout()
        quality_row.addWidget(QLabel("Calidad:"))
        self.combo_quality = QComboBox()
        for q in ["2K", "1080p", "720p", "480p"]:
            self.combo_quality.addItem(q)
        self.combo_quality.setCurrentText("1080p")
        quality_row.addWidget(self.combo_quality)
        quality_row.addStretch()
        layout.addLayout(quality_row)

        # ── Opciones de fuente ─────────────────────
        grp = QGroupBox("¿Qué querés compartir?")
        grp_layout = QVBoxLayout(grp)

        self.radio_screen = QPushButton("🖥️  Pantalla completa")
        self.radio_window = QPushButton("🪟  Ventana de aplicación")
        self.radio_region = QPushButton("✂️  Seleccionar región")
        for btn in (self.radio_screen, self.radio_window, self.radio_region):
            btn.setCheckable(True)
            btn.setStyleSheet(
                "QPushButton { text-align:left; padding:8px 12px; font-size:13px; "
                "border:1px solid #555; border-radius:4px; }"
                "QPushButton:checked { background:#2563eb; color:white; border-color:#1d4ed8; }"
            )
        self.radio_screen.setChecked(True)
        self.radio_screen.clicked.connect(lambda: self._select_mode("screen"))
        self.radio_window.clicked.connect(lambda: self._select_mode("window"))
        self.radio_region.clicked.connect(lambda: self._select_mode("region"))
        grp_layout.addWidget(self.radio_screen)
        grp_layout.addWidget(self.radio_window)
        grp_layout.addWidget(self.radio_region)
        layout.addWidget(grp)

        # ── Lista de ventanas (visible solo en modo "window") ─────────────────
        self.grp_windows = QGroupBox("Ventanas disponibles")
        win_layout = QVBoxLayout(self.grp_windows)

        self.list_windows = QTreeWidget()
        self.list_windows.setHeaderHidden(True)
        self.list_windows.setRootIsDecorated(False)
        self.list_windows.setAlternatingRowColors(True)
        win_layout.addWidget(self.list_windows)

        refresh_btn = QPushButton("↻  Actualizar lista")
        refresh_btn.clicked.connect(self._refresh_windows)
        win_layout.addWidget(refresh_btn)

        layout.addWidget(self.grp_windows)
        self.grp_windows.setVisible(False)

        # ── Botones OK / Cancelar ─────────────────
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self._on_accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _select_mode(self, mode: str):
        self.result_choice = mode
        self.radio_screen.setChecked(mode == "screen")
        self.radio_window.setChecked(mode == "window")
        self.radio_region.setChecked(mode == "region")
        self.grp_windows.setVisible(mode == "window")
        if mode == "window" and self.list_windows.topLevelItemCount() == 0:
            self._refresh_windows()

    def _refresh_windows(self):
        from video import list_windows
        self.list_windows.clear()
        wins = list_windows()
        self._wins_data = wins
        if not wins:
            item = QTreeWidgetItem(["(No se encontraron ventanas — ¿wmctrl instalado?)"])
            item.setDisabled(True)
            self.list_windows.addTopLevelItem(item)
            return
        for i, win in enumerate(wins):
            title = win["title"]
            if len(title) > 70:
                title = title[:67] + "…"
            item = QTreeWidgetItem([title])
            item.setData(0, Qt.ItemDataRole.UserRole, i)
            self.list_windows.addTopLevelItem(item)
        self.list_windows.setCurrentItem(self.list_windows.topLevelItem(0))

    def _on_accept(self):
        self.result_quality = self.combo_quality.currentText()
        if self.result_choice == "window":
            sel = self.list_windows.currentItem()
            if sel is None:
                QMessageBox.warning(self, "Sin selección", "Elegí una ventana de la lista.")
                return
            idx = sel.data(0, Qt.ItemDataRole.UserRole)
            if idx is not None and hasattr(self, "_wins_data"):
                self.result_window = self._wins_data[idx]
        self.accept()


class RegionSelectorOverlay(QDialog):
    """
    Overlay transparente a pantalla completa que permite al usuario
    dibujar un rectangulo con el mouse para seleccionar la region a capturar.
    """

    def __init__(self):
        super().__init__(None)
        self.setWindowTitle("Seleccionar región — arrastrá para marcar")
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setCursor(Qt.CursorShape.CrossCursor)

        screen = QApplication.primaryScreen().geometry()
        self.setGeometry(screen)

        self.selected_rect = None  # (x, y, w, h) en coords globales
        self._start = None
        self._end   = None
        self._dragging = False

        # Instruccion visible
        self._hint = QLabel(
            "Arrastrá para seleccionar una región  ·  ESC para cancelar",
            self
        )
        self._hint.setStyleSheet(
            "color:white; background:rgba(0,0,0,160); "
            "padding:6px 12px; border-radius:4px; font-size:13px;"
        )
        self._hint.adjustSize()
        self._hint.move(
            (screen.width() - self._hint.width()) // 2, 20
        )

    def paintEvent(self, event):
        from PyQt6.QtGui import QPainter, QColor, QPen
        painter = QPainter(self)

        # Fondo semitransparente
        painter.fillRect(self.rect(), QColor(0, 0, 0, 90))

        if self._start and self._end:
            x1, y1 = self._start.x(), self._start.y()
            x2, y2 = self._end.x(),   self._end.y()
            rx, ry = min(x1, x2), min(y1, y2)
            rw, rh = abs(x2 - x1), abs(y2 - y1)

            from PyQt6.QtCore import QRect
            # Recorte: la zona seleccionada queda "transparente"
            painter.setCompositionMode(
                QPainter.CompositionMode.CompositionMode_Clear
            )
            painter.fillRect(QRect(rx, ry, rw, rh), QColor(0, 0, 0, 255))

            # Borde de la selección
            painter.setCompositionMode(
                QPainter.CompositionMode.CompositionMode_SourceOver
            )
            pen = QPen(QColor(37, 99, 235), 2)
            painter.setPen(pen)
            painter.drawRect(QRect(rx, ry, rw, rh))

            # Dimensiones
            painter.setPen(QColor(255, 255, 255))
            painter.drawText(rx + 4, ry - 6, f"{rw} × {rh} px")

        painter.end()

    def mousePressEvent(self, event):
        from PyQt6.QtCore import Qt as QtC
        if event.button() == QtC.MouseButton.LeftButton:
            self._start    = event.pos()
            self._end      = event.pos()
            self._dragging = True

    def mouseMoveEvent(self, event):
        if self._dragging:
            self._end = event.pos()
            self.update()

    def mouseReleaseEvent(self, event):
        from PyQt6.QtCore import Qt as QtC
        if event.button() == QtC.MouseButton.LeftButton and self._dragging:
            self._dragging = False
            self._end = event.pos()
            x1, y1 = self._start.x(), self._start.y()
            x2, y2 = self._end.x(),   self._end.y()
            rx, ry = min(x1, x2), min(y1, y2)
            rw, rh = abs(x2 - x1), abs(y2 - y1)
            if rw > 20 and rh > 20:
                # Convertir a coords globales (el widget ocupa toda la pantalla)
                offset = self.geometry().topLeft()
                self.selected_rect = (rx + offset.x(), ry + offset.y(), rw, rh)
                self.accept()
            else:
                self._start = None
                self._end   = None
                self.update()

    def keyPressEvent(self, event):
        from PyQt6.QtCore import Qt as QtC
        if event.key() == QtC.Key.Key_Escape:
            self.reject()


# ──────────────────────────────────────────────
# Diálogo de conexión
# ──────────────────────────────────────────────

class ConnectDialog(QDialog):
    def __init__(self, parent=None, last_host="", last_user=""):
        super().__init__(parent)
        self.setWindowTitle("Conectar al servidor")
        self.setFixedSize(360, 240)

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.host_input = QLineEdit(last_host or "localhost")
        self.port_input = QLineEdit("64730")
        self.user_input = QLineEdit(last_user)
        self.pass_input = QLineEdit()
        self.pass_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.tls_check = QCheckBox("Usar TLS (recomendado)")
        self.tls_check.setChecked(True)

        form.addRow("Servidor:", self.host_input)
        form.addRow("Puerto:", self.port_input)
        form.addRow("Usuario:", self.user_input)
        form.addRow("Contraseña:", self.pass_input)
        form.addRow("", self.tls_check)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout.addLayout(form)
        layout.addWidget(buttons)

        # Enter en contraseña = OK
        self.pass_input.returnPressed.connect(self.accept)

    @property
    def values(self):
        return {
            "host": self.host_input.text().strip(),
            "port": int(self.port_input.text().strip() or "64730"),
            "username": self.user_input.text().strip(),
            "password": self.pass_input.text(),
            "use_tls": self.tls_check.isChecked(),
        }


# ──────────────────────────────────────────────
# Ventana principal
# ──────────────────────────────────────────────

class MainWindow(QMainWindow):

    # Signals para actualizar la UI desde callbacks async
    sig_room_list     = pyqtSignal(list)
    sig_user_list     = pyqtSignal(str, list)   # room_id, users
    sig_user_join     = pyqtSignal(dict)
    sig_user_leave    = pyqtSignal(dict)
    sig_chat          = pyqtSignal(dict)
    sig_stream_start  = pyqtSignal(dict)
    sig_stream_stop   = pyqtSignal(dict)
    sig_stream_locked = pyqtSignal(dict)
    sig_error         = pyqtSignal(str)
    sig_connected     = pyqtSignal()
    sig_disconnected  = pyqtSignal()
    sig_video_frame   = pyqtSignal(int, object)  # user_id, frame numpy BGR

    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.setMinimumSize(800, 560)
        self.resize(1000, 680)

        # Cargar configuración persistente
        config.load()

        # Estado
        self.conn: Optional[ServerConnection] = None
        self.async_thread = AsyncThread()
        self.async_thread.start()
        self.current_room: Optional[str] = None
        self._rooms: dict = {}
        self._users: dict = {}  # user_id -> info

        # Audio / Video
        self.audio_capture: Optional[AudioCapture] = None
        output_device = config.get("output_device", -1)
        output_volume = config.get("output_volume", 100)
        self.audio_playback = AudioPlayback(
            device=output_device if output_device != -1 else None,
            volume=output_volume,
        )
        self.video_mgr: Optional[VideoManager] = None

        self._build_ui()
        self._connect_signals()
        self._start_ping_timer()
        self._restore_geometry()
        self._setup_shortcuts()

    # ──────────────────────────────────────────────
    # Construcción de UI
    # ──────────────────────────────────────────────

    def _build_ui(self):
        """Construye toda la interfaz gráfica."""
        # ── Menú ──────────────────────────────────
        menubar = self.menuBar()

        server_menu = menubar.addMenu("Servidor")
        self.action_connect    = server_menu.addAction("Conectar…", self._on_connect)
        self.action_disconnect = server_menu.addAction("Desconectar", self._on_disconnect)
        self.action_disconnect.setEnabled(False)
        server_menu.addSeparator()
        server_menu.addAction("Salir", self.close)

        audio_menu = menubar.addMenu("Audio")
        audio_menu.addAction("Configurar audio…", self._on_audio_settings)

        video_menu = menubar.addMenu("Video")
        self.action_camera     = video_menu.addAction("Compartir cámara", self._on_start_camera)
        self.action_screen     = video_menu.addAction("Compartir pantalla", self._on_start_screen)
        self.action_file       = video_menu.addAction("Reproducir archivo…", self._on_start_file)
        video_menu.addSeparator()
        self.action_stop_video = video_menu.addAction("Detener video", self._on_stop_video)

        for a in [self.action_camera, self.action_screen, self.action_file, self.action_stop_video]:
            a.setEnabled(False)

        help_menu = menubar.addMenu("Ayuda")
        help_menu.addAction("Acerca de", self._on_about)

        # ── Layout central ──────────────────────
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(4, 4, 4, 4)
        main_layout.setSpacing(4)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        main_layout.addWidget(splitter)

        # Panel izquierdo
        left_panel = QWidget()
        left_panel.setMinimumWidth(200)
        left_panel.setMaximumWidth(280)
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)

        self.lbl_server = QLabel("Sin conectar")
        self.lbl_server.setStyleSheet("font-weight: bold; padding: 4px;")
        left_layout.addWidget(self.lbl_server)

        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setRootIsDecorated(True)
        self.tree.itemDoubleClicked.connect(self._on_room_double_click)
        left_layout.addWidget(self.tree)

        # Botones mute/deafen
        btn_row = QHBoxLayout()
        self.btn_mute   = QPushButton("🎤 Silenciar")
        self.btn_deafen = QPushButton("🔇 Ensordecer")
        self.btn_mute.setCheckable(True)
        self.btn_deafen.setCheckable(True)
        self.btn_mute.setEnabled(False)
        self.btn_deafen.setEnabled(False)
        self.btn_mute.clicked.connect(self._on_toggle_mute)
        self.btn_deafen.clicked.connect(self._on_toggle_deafen)
        btn_row.addWidget(self.btn_mute)
        btn_row.addWidget(self.btn_deafen)
        left_layout.addLayout(btn_row)

        splitter.addWidget(left_panel)

        # Panel central
        center_panel = QWidget()
        center_layout = QVBoxLayout(center_panel)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(4)

        self.video_area = QLabel("Sin video")
        self.video_area.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.video_area.setMinimumHeight(200)
        self.video_area.setStyleSheet(
            "background: #111; color: #555; font-size: 14px; border-radius: 6px;"
        )
        self.video_area.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding
        )
        center_layout.addWidget(self.video_area, stretch=3)

        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.chat_display.setMaximumHeight(200)
        self.chat_display.setStyleSheet("font-size: 13px;")
        center_layout.addWidget(self.chat_display, stretch=1)

        chat_input_row = QHBoxLayout()
        self.chat_input = QLineEdit()
        self.chat_input.setPlaceholderText("Escribí un mensaje… (Enter para enviar)")
        self.chat_input.setEnabled(False)
        self.chat_input.returnPressed.connect(self._on_send_chat)
        btn_send = QPushButton("Enviar")
        btn_send.clicked.connect(self._on_send_chat)
        chat_input_row.addWidget(self.chat_input)
        chat_input_row.addWidget(btn_send)
        center_layout.addLayout(chat_input_row)

        splitter.addWidget(center_panel)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)

        # Barra de estado
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.lbl_status = QLabel("Desconectado")
        self.status_bar.addWidget(self.lbl_status)
        self.lbl_latency = QLabel("")
        self.status_bar.addPermanentWidget(self.lbl_latency)

    def _connect_signals(self):
        """Conecta todas las señales de la UI."""
        self.sig_room_list.connect(self._update_room_list)
        self.sig_user_list.connect(self._update_user_list)
        self.sig_user_join.connect(self._on_user_join_ui)
        self.sig_user_leave.connect(self._on_user_leave_ui)
        self.sig_chat.connect(self._append_chat)
        self.sig_stream_start.connect(self._on_stream_start_ui)
        self.sig_stream_stop.connect(self._on_stream_stop_ui)
        self.sig_stream_locked.connect(self._on_stream_locked_ui)
        self.sig_error.connect(self._show_error)
        self.sig_connected.connect(self._on_connected_ui)
        self.sig_disconnected.connect(self._on_disconnected_ui)
        self.sig_video_frame.connect(self._on_video_frame_ui)

    # ──────────────────────────────────────────────
    # Acciones
    # ──────────────────────────────────────────────

    def _on_connect(self):
        dlg = ConnectDialog(
            self,
            last_host=config.get("last_host", ""),
            last_user=config.get("last_username", "")
        )
        dlg.port_input.setText(str(config.get("last_port", 64730)))
        dlg.tls_check.setChecked(config.get("use_tls", True))
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        v = dlg.values
        config.set("last_host",     v["host"])
        config.set("last_port",     v["port"])
        config.set("last_username", v["username"])
        config.set("use_tls",       v["use_tls"])
        config.save()
        self._do_connect(v["host"], v["port"], v["username"], v["password"], v["use_tls"])

    def _on_disconnect(self):
        """Desconecta del servidor de forma segura."""
        if hasattr(self, "conn") and self.conn:
            self.async_thread.submit(self.conn.disconnect())

        self.current_room = None

        if hasattr(self, "video_mgr") and self.video_mgr:
            self.async_thread.submit(self.video_mgr.stop())

        if hasattr(self, "audio_capture") and self.audio_capture:
            self.audio_capture.stop()

        if hasattr(self, "audio_playback") and self.audio_playback:
            self.audio_playback.stop()

        self.sig_disconnected.emit()

    def _do_connect(self, host, port, username, password, use_tls):
        """Método interno para conectar."""
        self.lbl_status.setText(f"Conectando a {host}:{port}…")

        self.conn = ServerConnection(host, port, use_tls)
        self.conn._loop = self.async_thread.loop
        self._register_handlers()

        def _connect():
            return self.conn.connect(username, password)

        future = self.async_thread.submit(_connect())

        def _check():
            if not future.done():
                QTimer.singleShot(100, _check)
                return
            try:
                ok, msg = future.result()
            except Exception as e:
                ok, msg = False, str(e)
            if ok:
                self.sig_connected.emit()
            else:
                self.sig_error.emit(f"No se pudo conectar: {msg}")

        QTimer.singleShot(100, _check)

    def _register_handlers(self):
        c = self.conn
        c.on(MSG_ROOM_LIST,     lambda p: self.sig_room_list.emit(p.get("rooms", [])))
        c.on(MSG_USER_LIST,     lambda p: self.sig_user_list.emit(p["room_id"], p.get("users", [])))
        c.on(MSG_USER_JOIN,     lambda p: self.sig_user_join.emit(p))
        c.on(MSG_USER_LEAVE,    lambda p: self.sig_user_leave.emit(p))
        c.on(MSG_CHAT,          lambda p: self.sig_chat.emit(p))
        c.on(MSG_STREAM_START,  lambda p: self.sig_stream_start.emit(p))
        c.on(MSG_STREAM_STOP,   lambda p: self.sig_stream_stop.emit(p))
        c.on(MSG_STREAM_LOCKED, lambda p: self.sig_stream_locked.emit(p))
        c.on(MSG_ERROR,         lambda p: self.sig_error.emit(p.get("reason", "Error desconocido")))
        c.on(MSG_PONG,          self._on_pong)

        # El servidor nos informa el endpoint UDP de un nuevo peer.
        # Hay que llamar explícitamente a add_peer para que _peers se llene
        # y _send_to_all tenga a quién mandarle los frames.
        def on_p2p_endpoint(p):
            uid  = p.get("user_id")
            name = p.get("username", "?")
            ip   = p.get("ip")
            port = p.get("port")
            if uid and ip and port:
                self.conn.udp.add_peer(uid, ip, int(port))
            log.info(f"Endpoint P2P recibido: {name} ({uid}) en {ip}:{port}")
            self._append_system(f"🔗 Conectando P2P con {name}…")
        c.on(MSG_P2P_ENDPOINT, on_p2p_endpoint)

        # NOTA: los callbacks de media UDP (on_audio, on_video) se registran
        # en _on_connected_ui(), DESPUÉS de que connect() termine y udp.start()
        # haya corrido. Si se registran aquí, el canal UDP todavía no existe.

    def _on_room_double_click(self, item: QTreeWidgetItem, col: int):
        """Se ejecuta al hacer doble clic en una sala."""
        # Si el ítem es un hijo (usuario dentro de sala), subir al padre
        if item.parent() is not None:
            item = item.parent()

        room_id = item.data(0, Qt.ItemDataRole.UserRole)
        if not room_id or not self.conn or not self.conn.is_connected:
            return

        # Ya estamos en esa sala, no hacer nada
        if self.current_room == room_id:
            return

        # El servidor hace leave automático al recibir join,
        # no hay que mandar leave por separado (causaba doble leave).
        self.current_room = room_id
        self.async_thread.submit(self.conn.join_room(room_id))
        self.chat_display.clear()
        self._append_system(f"✅ Entraste a: {item.text(0)}")

    def _on_send_chat(self):
        """Envía un mensaje de chat."""
        text = self.chat_input.text().strip()
        if not text or not self.conn or not self.conn.is_connected:
            return
        self.chat_input.clear()
        self.async_thread.submit(self.conn.send_chat(text))

    def _on_toggle_mute(self, checked: bool):
        if self.audio_capture:
            self.audio_capture.set_muted(checked)
        self.btn_mute.setText("🔴 Silenciado" if checked else "🎤 Silenciar")

    def _on_toggle_deafen(self, checked: bool):
        self.audio_playback.set_deafened(checked)
        self.btn_deafen.setText("🔴 Ensordecido" if checked else "🔇 Ensordecer")

    def _on_start_camera(self):
        if self.video_mgr:
            self.async_thread.submit(self.video_mgr.start_camera())
            self._append_system("Compartiendo cámara…")

    def _on_start_screen(self):
        if not self.video_mgr:
            return
        dlg = ScreenPickerDialog(self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        choice  = dlg.result_choice
        quality = dlg.result_quality

        if choice == "screen":
            self.async_thread.submit(self.video_mgr.start_screen(quality))
            self._append_system(f"Compartiendo pantalla completa ({quality})…")

        elif choice == "window":
            win = dlg.result_window
            if not win:
                return
            self.async_thread.submit(
                self.video_mgr.start_window(
                    win.get("hwnd") or win.get("wid"),
                    rect=win.get("rect"),
                    quality=quality,
                )
            )
            self._append_system(f"Compartiendo ventana: {win['title'][:50]} ({quality})…")

        elif choice == "region":
            sel = RegionSelectorOverlay()
            sel.exec()
            if sel.selected_rect:
                x, y, w, h = sel.selected_rect
                self.async_thread.submit(
                    self.video_mgr.start_region(x, y, w, h, quality)
                )
                self._append_system(
                    f"Compartiendo región {w}×{h} en ({x},{y}) ({quality})…"
                )

    def _on_start_file(self):
        from PyQt6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleccioná un video",
            filter="Videos (*.mp4 *.mkv *.avi *.mov *.webm *.ts);;Todos los archivos (*)"
        )
        if path and self.video_mgr:
            self.async_thread.submit(self.video_mgr.start_file(path))
            self._append_system(f"Reproduciendo: {path}")

    def _on_stop_video(self):
        if self.video_mgr:
            self.async_thread.submit(self.video_mgr.stop())
            self._append_system("Video detenido")

    def _on_audio_settings(self):
        dlg = SettingsDialog(self)
        dlg.exec()

    def _on_about(self):
        QMessageBox.about(
            self, f"Acerca de {APP_NAME}",
            f"<b>{APP_NAME}</b> v{APP_VERSION}<br><br>"
            "Cliente de voz y video FranBle.<br>"
            "Audio: Opus · Video: JPEG/OpenCV<br><br>"
            "Resolución máxima: 2K (2560×1440)"
        )

    # ──────────────────────────────────────────────
    # Actualizaciones de UI desde signals
    # ──────────────────────────────────────────────

    def _on_connected_ui(self):
        """Se llama cuando se conecta exitosamente al servidor."""
        self.lbl_server.setText(f"🟢 {self.conn.username}")
        self.lbl_status.setText(f"Conectado como {self.conn.username}")
        self.action_connect.setEnabled(False)
        self.action_disconnect.setEnabled(True)
        self.chat_input.setEnabled(True)
        self.btn_mute.setEnabled(True)
        self.btn_deafen.setEnabled(True)

        for a in [self.action_camera, self.action_screen, self.action_file]:
            a.setEnabled(True)

        # Audio
        self.audio_playback.start()

        def on_audio_frame(opus: bytes):
            # Llamada directa (síncrona) — send_audio_udp no es async
            if self.conn and self.conn.is_connected and self.current_room:
                self.conn.send_audio_udp(opus)

        input_device = config.get("input_device", -1)
        self.audio_capture = AudioCapture(
            on_frame=on_audio_frame,
            device=input_device if input_device != -1 else None,
            vad_threshold=config.get("vad_threshold", 500),
            volume=config.get("input_volume", 100),
        )
        self.audio_capture.start()

        # Video
        self.video_mgr = VideoManager(self.conn, audio_playback=self.audio_playback)
        self.video_mgr.on_remote_frame = self._on_remote_frame

        # Registrar callbacks de media UDP AQUÍ, después de que connect() terminó
        # y udp.start() ya corrió. Esto garantiza que on_audio/on_video no se pierden.
        def on_udp_audio(user_id: int, opus_bytes: bytes):
            if self.audio_playback:
                self.audio_playback.push_frame(user_id, opus_bytes)

        def on_udp_video(user_id: int, jpeg_bytes: bytes):
            if self.video_mgr:
                self.video_mgr.receive_frame(user_id, jpeg_bytes)

        self.conn.set_media_callbacks(on_udp_audio, on_udp_video)

        self._append_system("✅ Conectado correctamente.")

    def _on_disconnected_ui(self):
        """Se llama cuando se desconecta del servidor."""
        self.lbl_server.setText("Sin conectar")
        self.lbl_status.setText("Desconectado")
        self.action_connect.setEnabled(True)
        self.action_disconnect.setEnabled(False)
        self.chat_input.setEnabled(False)
        self.btn_mute.setEnabled(False)
        self.btn_deafen.setEnabled(False)

        for a in [self.action_camera, self.action_screen, self.action_file, self.action_stop_video]:
            a.setEnabled(False)

        self.tree.clear()
        self.video_area.setText("Sin video")

        if self.audio_capture:
            self.audio_capture.stop()
        if self.audio_playback:
            self.audio_playback.stop()

        self._append_system("🔌 Desconectado del servidor.")

    def _update_room_list(self, rooms: list):
        """Actualiza la lista de salas SIN borrar los hijos (usuarios) ya cargados.
        Solo actualiza el texto del contador y agrega/elimina salas si cambian."""
        self._rooms = {r["id"]: r for r in rooms}

        # Índice de ítems actuales en el árbol
        existing = {}
        for i in range(self.tree.topLevelItemCount()):
            it = self.tree.topLevelItem(i)
            rid = it.data(0, Qt.ItemDataRole.UserRole)
            existing[rid] = it

        new_ids = {r["id"] for r in rooms}

        # Eliminar salas que ya no existen
        for rid in list(existing.keys()):
            if rid not in new_ids:
                idx = self.tree.indexOfTopLevelItem(existing[rid])
                self.tree.takeTopLevelItem(idx)

        # Actualizar o agregar salas
        for pos, room in enumerate(rooms):
            rid = room["id"]
            label = f"📢 {room['name']} ({room['user_count']})"
            if rid in existing:
                # Solo actualizar el texto; respetar los hijos (usuarios) existentes
                existing[rid].setText(0, label)
            else:
                item = QTreeWidgetItem([label])
                item.setData(0, Qt.ItemDataRole.UserRole, rid)
                if room.get("description"):
                    item.setToolTip(0, room["description"])
                self.tree.addTopLevelItem(item)
                item.setExpanded(True)

    def _update_user_list(self, room_id: str, users: list):
        self._users = {u["id"]: u for u in users}
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if item.data(0, Qt.ItemDataRole.UserRole) == room_id:
                item.takeChildren()
                for u in users:
                    icon  = "🎤" if not u.get("is_muted") else "🔇"
                    video = " 📹" if u.get("is_streaming") else ""
                    ui = QTreeWidgetItem([f"{icon} {u['username']}{video}"])
                    ui.setData(0, Qt.ItemDataRole.UserRole + 1, u["id"])
                    item.addChild(ui)
                item.setExpanded(True)
                break

        my_id = self.conn.user_id if self.conn else None
        streaming_user = next((u for u in users if u.get("is_streaming")), None)
        if streaming_user and streaming_user["id"] != my_id:
            self._set_video_buttons_locked(locked=True, other_name=streaming_user["username"])
        else:
            self._set_video_buttons_locked(
                locked=False,
                for_me=(streaming_user is not None and streaming_user.get("id") == my_id)
            )

    def _on_user_join_ui(self, payload: dict):
        self._append_system(f"→ {payload['username']} se unió a la sala")
        room_id = payload.get("room_id")
        user_id = payload.get("user_id")
        username = payload.get("username", "")
        if not room_id:
            return
        # Agregar el usuario al árbol de la sala correspondiente
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if item.data(0, Qt.ItemDataRole.UserRole) == room_id:
                # Verificar que no esté ya en el árbol
                for j in range(item.childCount()):
                    child = item.child(j)
                    if child.data(0, Qt.ItemDataRole.UserRole + 1) == user_id:
                        return  # ya estaba, no duplicar
                ui = QTreeWidgetItem([f"🎤 {username}"])
                ui.setData(0, Qt.ItemDataRole.UserRole + 1, user_id)
                item.addChild(ui)
                item.setExpanded(True)
                # Actualizar contador de usuarios en el nombre de la sala
                count = item.childCount()
                room_name = self._rooms.get(room_id, {}).get("name", room_id)
                item.setText(0, f"📢 {room_name} ({count})")
                break

    def _on_user_leave_ui(self, payload: dict):
        self._append_system(f"← {payload['username']} salió de la sala")
        room_id = payload.get("room_id")
        user_id = payload.get("user_id")
        self.audio_playback.remove_user(user_id)
        if not room_id:
            return
        # Quitar el usuario del árbol de la sala correspondiente
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if item.data(0, Qt.ItemDataRole.UserRole) == room_id:
                for j in range(item.childCount()):
                    child = item.child(j)
                    if child.data(0, Qt.ItemDataRole.UserRole + 1) == user_id:
                        item.removeChild(child)
                        break
                # Actualizar contador de usuarios en el nombre de la sala
                count = item.childCount()
                room_name = self._rooms.get(room_id, {}).get("name", room_id)
                item.setText(0, f"📢 {room_name} ({count})")
                break

    def _append_chat(self, payload: dict):
        from_name = payload.get("from_name", "?")
        text      = payload.get("text", "")
        self.chat_display.append(f"<b>{from_name}:</b> {text}")

    def _append_system(self, text: str):
        self.chat_display.append(f'<i style="color: gray;">{text}</i>')

    def _on_stream_start_ui(self, payload: dict):
        """Alguien obtuvo el turno de transmisión."""
        stream_types = {"camera": "cámara", "screen": "pantalla", "file": "archivo"}
        tipo = stream_types.get(payload.get("type", ""), "video")
        uid  = payload.get("user_id")
        name = payload.get("username", "")
        my_id = self.conn.user_id if self.conn else None

        if uid == my_id:
            self._append_system(f"📹 Estás transmitiendo {tipo}")
            self.action_stop_video.setEnabled(True)
            self._set_video_buttons_locked(locked=False, for_me=True)
        else:
            self._append_system(f"📹 {name} está transmitiendo {tipo} — esperá tu turno")
            self._set_video_buttons_locked(locked=True, other_name=name)

    def _on_stream_stop_ui(self, payload: dict):
        """El que transmitía dejó de hacerlo."""
        name  = payload.get("username", "")
        uid   = payload.get("user_id")
        my_id = self.conn.user_id if self.conn else None

        if uid == my_id:
            self._append_system("⬛ Dejaste de transmitir")
        else:
            self._append_system(f"⬛ {name} dejó de transmitir — la sala está libre")

        self.action_stop_video.setEnabled(False)
        self._set_video_buttons_locked(locked=False, for_me=False)

    def _on_stream_locked_ui(self, payload: dict):
        """Sala ocupada."""
        name = payload.get("username", "alguien")
        self._append_system(f"🔒 No podés transmitir: {name} ya está transmitiendo")
        QMessageBox.information(
            self,
            "Sala ocupada",
            f"<b>{name}</b> ya está transmitiendo.\n\nEsperá a que termine."
        )

    def _set_video_buttons_locked(self, locked: bool, other_name: str = "", for_me: bool = False):
        """Habilita/deshabilita botones de video."""
        can_start = not locked and not for_me
        self.action_camera.setEnabled(can_start)
        self.action_screen.setEnabled(can_start)
        self.action_file.setEnabled(can_start)

        if for_me:
            self.action_stop_video.setEnabled(True)
        elif not locked:
            self.action_stop_video.setEnabled(False)

    def _show_error(self, msg: str):
        self.lbl_status.setText(f"Error: {msg}")
        if "Desconectado" in msg:
            self._on_disconnected_ui()

    def _on_remote_frame(self, user_id: int, frame):
        """Llamado desde thread de video — emite señal para actualizar UI en hilo Qt."""
        self.sig_video_frame.emit(user_id, frame)

    def _on_video_frame_ui(self, user_id: int, frame):
        """Actualiza el área de video — siempre corre en el hilo Qt."""
        now = time.time()
        if now - getattr(self, "last_frame_time", 0) < 0.033:   # ~30 fps
            return
        self.last_frame_time = now

        from video import VideoWidget
        pixmap = VideoWidget.frame_to_pixmap(frame)
        if pixmap:
            scaled = pixmap.scaled(
                self.video_area.size(),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
            self.video_area.setPixmap(scaled)

    # ──────────────────────────────────────────────
    # Ping / latencia
    # ──────────────────────────────────────────────

    def _start_ping_timer(self):
        self._ping_timer = QTimer()
        self._ping_timer.setInterval(5000)
        self._ping_timer.timeout.connect(self._do_ping)
        self._ping_timer.start()
        self._ping_sent_at = 0

    def _do_ping(self):
        if self.conn and self.conn.is_connected:
            self._ping_sent_at = time.time() * 1000
            self.async_thread.submit(self.conn.ping())

    def _on_pong(self, payload: dict):
        if self._ping_sent_at:
            latency = int(time.time() * 1000 - self._ping_sent_at)
            self.lbl_latency.setText(f"Latencia: {latency} ms")

    def _restore_geometry(self):
        geom = config.get("window_geometry")
        if geom:
            try:
                self.restoreGeometry(QByteArray.fromHex(geom.encode()))
            except Exception:
                pass

    def _setup_shortcuts(self):
        """Atajos de teclado globales."""
        QShortcut(QKeySequence("Ctrl+M"), self, self.btn_mute.toggle)
        QShortcut(QKeySequence("Ctrl+D"), self, self.btn_deafen.toggle)
        QShortcut(QKeySequence("Ctrl+Return"), self, self._on_send_chat)

    def closeEvent(self, event):
        # 1. Detener todo antes de matar el loop de asyncio
        if self.video_mgr:
            self.async_thread.submit(self.video_mgr.stop())
        if self.audio_capture:
            self.audio_capture.stop()
        if self.audio_playback:
            self.audio_playback.stop()

        # 2. Desconectar servidor
        if self.conn:
            self.async_thread.submit(self.conn.disconnect())

        # 3. Guardar config
        config.set("window_geometry", self.saveGeometry().toHex().data().decode())
        config.save()

        # 4. Detener asyncio thread
        if self.async_thread.loop:
            self.async_thread.loop.call_soon_threadsafe(self.async_thread.loop.stop)
        self.async_thread.quit()
        self.async_thread.wait(1500)

        event.accept()


# ──────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────

def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setStyle("Fusion")

    win = MainWindow()
    win.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
