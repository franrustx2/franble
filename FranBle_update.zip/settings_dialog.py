"""
Diálogo de configuración de audio y video — PyQt6
"""

import logging
import random
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import (
    QDialog, QTabWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QFormLayout, QLabel, QComboBox, QSlider, QCheckBox,
    QKeySequenceEdit, QDialogButtonBox, QGroupBox,
    QProgressBar, QSpinBox,
)
from PyQt6.QtGui import QKeySequence

from config import config

log = logging.getLogger("settings")


def list_audio_devices() -> tuple:
    """Retorna (inputs, outputs) con filtrado de duplicados y virtuales.
    Delega en audio.py que tiene la logica completa de filtrado."""
    from audio import list_audio_devices as _list
    return _list()


def list_cameras() -> list[tuple[int, str]]:
    """Detecta cámaras disponibles (OpenCV)."""
    cameras = []
    try:
        import cv2
        for i in range(5):
            cap = cv2.VideoCapture(i, cv2.CAP_DSHOW)
            if cap.isOpened():
                cameras.append((i, f"Cámara {i}"))
                cap.release()
    except Exception:
        pass
    if not cameras:
        cameras = [(0, "Cámara 0 (por defecto)")]
    return cameras


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configuración")
        self.setMinimumSize(520, 500)

        self.audio_capture_for_meter = None  # Para medidor real de micrófono

        layout = QVBoxLayout(self)
        tabs = QTabWidget()
        layout.addWidget(tabs)

        tabs.addTab(self._build_audio_tab(), "Audio")
        tabs.addTab(self._build_video_tab(), "Video")
        tabs.addTab(self._build_ptt_tab(), "Push-to-Talk")

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel |
            QDialogButtonBox.StandardButton.RestoreDefaults
        )
        buttons.accepted.connect(self._save_and_accept)
        buttons.rejected.connect(self.reject)
        buttons.button(QDialogButtonBox.StandardButton.RestoreDefaults).clicked.connect(self._reset_defaults)
        layout.addWidget(buttons)

        self._load_values()

    # ── Audio Tab ─────────────────────────────────────
    def _build_audio_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)

        # Dispositivos
        dev_group = QGroupBox("Dispositivos")
        form = QFormLayout(dev_group)

        self.cb_input = QComboBox()
        self.cb_output = QComboBox()
        form.addRow("Micrófono:", self.cb_input)
        form.addRow("Salida de audio:", self.cb_output)
        layout.addWidget(dev_group)

        # Volúmenes
        vol_group = QGroupBox("Volumen")
        vol_layout = QFormLayout(vol_group)

        self.sl_input_vol = self._make_slider(0, 200, 100)
        self.lbl_input_vol = QLabel("100%")
        self.sl_input_vol.valueChanged.connect(lambda v: self.lbl_input_vol.setText(f"{v}%"))

        self.sl_output_vol = self._make_slider(0, 200, 100)
        self.lbl_output_vol = QLabel("100%")
        self.sl_output_vol.valueChanged.connect(lambda v: self.lbl_output_vol.setText(f"{v}%"))

        row_in = self._slider_row(self.sl_input_vol, self.lbl_input_vol)
        row_out = self._slider_row(self.sl_output_vol, self.lbl_output_vol)

        vol_layout.addRow("Micrófono:", row_in)
        vol_layout.addRow("Salida:", row_out)
        layout.addWidget(vol_group)

        # VAD
        vad_group = QGroupBox("Detección de voz (VAD)")
        vad_layout = QFormLayout(vad_group)

        self.sl_vad = self._make_slider(100, 3000, 500)
        self.lbl_vad = QLabel("500")
        self.sl_vad.valueChanged.connect(lambda v: self.lbl_vad.setText(str(v)))

        self.pb_mic_level = QProgressBar()
        self.pb_mic_level.setRange(0, 3000)
        self.pb_mic_level.setTextVisible(False)
        self.pb_mic_level.setFixedHeight(12)

        vad_layout.addRow("Sensibilidad VAD:", self._slider_row(self.sl_vad, self.lbl_vad))
        vad_layout.addRow("Nivel de micrófono:", self.pb_mic_level)
        layout.addWidget(vad_group)

        # Timer para medidor de micrófono
        self._mic_timer = QTimer()
        self._mic_timer.setInterval(50)
        self._mic_timer.timeout.connect(self._update_mic_level)
        self._mic_timer.start()

        # Poblar dispositivos
        inputs, outputs = list_audio_devices()
        for idx, name in inputs:
            self.cb_input.addItem(name, idx)
        for idx, name in outputs:
            self.cb_output.addItem(name, idx)

        layout.addStretch()
        return w

    def _update_mic_level(self):
        """Muestra el nivel REAL del micrófono."""
        if self.audio_capture_for_meter is None:
            try:
                from audio import AudioCapture
                def dummy_callback(opus): pass
                # Fix A: device=-1 no es válido para sounddevice, hay que pasar None
                raw_device = config.get("input_device", -1)
                device = raw_device if raw_device != -1 else None
                self.audio_capture_for_meter = AudioCapture(
                    on_frame=dummy_callback,
                    device=device,
                    vad_threshold=self.sl_vad.value(),
                )
                self.audio_capture_for_meter.start()
            except Exception as e:
                log.warning(f"No se pudo crear medidor de mic: {e}")
                self.pb_mic_level.setValue(0)
                return

        try:
            # Fix C: actualizar threshold en vivo según el slider
            self.audio_capture_for_meter._vad_threshold = self.sl_vad.value()

            level = int(getattr(self.audio_capture_for_meter, '_last_rms', 0))
            self.pb_mic_level.setValue(min(level * 6, 3000))
        except Exception:
            self.pb_mic_level.setValue(0)

    # ── Video Tab (sin cambios importantes) ───────
    def _build_video_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)

        cam_group = QGroupBox("Cámara")
        form = QFormLayout(cam_group)

        self.cb_camera = QComboBox()
        cameras = list_cameras()
        for idx, name in cameras:
            self.cb_camera.addItem(name, idx)

        self.cb_quality = QComboBox()
        for q in ["2K", "1080p", "720p", "480p"]:
            self.cb_quality.addItem(q)

        self.sp_fps = QSpinBox()
        self.sp_fps.setRange(10, 60)
        self.sp_fps.setValue(30)
        self.sp_fps.setSuffix(" fps")

        form.addRow("Cámara:", self.cb_camera)
        form.addRow("Calidad por defecto:", self.cb_quality)
        form.addRow("Fotogramas por segundo:", self.sp_fps)
        layout.addWidget(cam_group)

        screen_group = QGroupBox("Captura de pantalla")
        screen_form = QFormLayout(screen_group)
        self.cb_monitor = QComboBox()
        self.cb_monitor.addItem("Monitor principal (0)", 0)
        self.cb_monitor.addItem("Monitor secundario (1)", 1)
        screen_form.addRow("Monitor:", self.cb_monitor)
        layout.addWidget(screen_group)

        layout.addStretch()
        return w

    # ── PTT Tab (sin cambios) ─────────────────────
    def _build_ptt_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)

        self.chk_ptt = QCheckBox("Activar Push-to-Talk")
        layout.addWidget(self.chk_ptt)

        ptt_group = QGroupBox("Tecla PTT")
        ptt_form = QFormLayout(ptt_group)

        self.ptt_key_edit = QKeySequenceEdit()
        self.ptt_key_edit.setKeySequence(QKeySequence("F1"))
        ptt_form.addRow("Tecla:", self.ptt_key_edit)

        info = QLabel("Con PTT activado, el micrófono solo se transmite mientras mantenés presionada la tecla.")
        info.setStyleSheet("color: gray; font-size: 12px;")
        ptt_form.addRow("", info)
        layout.addWidget(ptt_group)

        self.chk_ptt.toggled.connect(ptt_group.setEnabled)
        layout.addStretch()
        return w

    # ── Carga / Guardado ──────────────────────────
    def _load_values(self):
        self._set_combo_by_data(self.cb_input, config.get("input_device", -1))
        self._set_combo_by_data(self.cb_output, config.get("output_device", -1))
        self.sl_input_vol.setValue(config.get("input_volume", 100))
        self.sl_output_vol.setValue(config.get("output_volume", 100))
        self.sl_vad.setValue(config.get("vad_threshold", 500))

        self._set_combo_by_data(self.cb_camera, config.get("camera_device", 0))
        idx = self.cb_quality.findText(config.get("default_quality", "720p"))
        if idx >= 0:
            self.cb_quality.setCurrentIndex(idx)
        self.sp_fps.setValue(config.get("fps", 30))
        self._set_combo_by_data(self.cb_monitor, config.get("screen_monitor", 0))

        self.chk_ptt.setChecked(config.get("push_to_talk", False))
        self.ptt_key_edit.setKeySequence(QKeySequence(config.get("ptt_key", "F1")))

    def _save_and_accept(self):
        config.set("input_device", self.cb_input.currentData())
        config.set("output_device", self.cb_output.currentData())
        config.set("input_volume", self.sl_input_vol.value())
        config.set("output_volume", self.sl_output_vol.value())
        config.set("vad_threshold", self.sl_vad.value())

        config.set("camera_device", self.cb_camera.currentData())
        config.set("default_quality", self.cb_quality.currentText())
        config.set("fps", self.sp_fps.value())
        config.set("screen_monitor", self.cb_monitor.currentData())

        config.set("push_to_talk", self.chk_ptt.isChecked())
        config.set("ptt_key", self.ptt_key_edit.keySequence().toString())

        config.save()
        self._mic_timer.stop()
        self.accept()

    def _reset_defaults(self):
        config.reset()
        self._load_values()

    def closeEvent(self, event):
        self._mic_timer.stop()
        if self.audio_capture_for_meter:
            self.audio_capture_for_meter.stop()
        super().closeEvent(event)

    def reject(self):
        self._mic_timer.stop()
        if self.audio_capture_for_meter:
            self.audio_capture_for_meter.stop()
        super().reject()

    # ── Helpers ───────────────────────────────────
    @staticmethod
    def _make_slider(min_val: int, max_val: int, default: int) -> QSlider:
        sl = QSlider(Qt.Orientation.Horizontal)
        sl.setRange(min_val, max_val)
        sl.setValue(default)
        return sl

    @staticmethod
    def _slider_row(slider: QSlider, label: QLabel) -> QWidget:
        w = QWidget()
        layout = QHBoxLayout(w)
        layout.setContentsMargins(0, 0, 0, 0)
        label.setFixedWidth(45)
        layout.addWidget(slider)
        layout.addWidget(label)
        return w

    @staticmethod
    def _set_combo_by_data(combo: QComboBox, value):
        for i in range(combo.count()):
            if combo.itemData(i) == value:
                combo.setCurrentIndex(i)
                return