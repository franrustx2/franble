"""
Capa de transporte FranBle.

TCP  → señalización (auth, salas, chat, stream start/stop).
UDP  → audio y video (P2P directo entre clientes o relay mínimo).

── Fragmentación de video ────────────────────────────────────────────────────
Los frames JPEG pueden superar el límite UDP (65 507 bytes). Para resoluciones
720p/1080p, un frame típico pesa entre 80 KB y 400 KB.

Cada fragmento de video lleva:
  [1B tipo] [4B sender_id] [2B seq] [2B frag_idx] [2B frag_total] [chunk]

El audio NO se fragmenta: frames Opus son siempre < 4 KB.

Formato relay — se anteponen 4 bytes de dest_user_id al paquete completo.
"""

import asyncio
import json
import logging
import socket
import ssl
import struct
import threading
import time
from pathlib import Path
from typing import Callable, Dict, Optional, Tuple

log = logging.getLogger("transport")

from protocol import (
    MSG_AUTH, MSG_AUTH_OK, MSG_AUTH_FAIL,
    MSG_ROOM_LIST, MSG_JOIN_ROOM, MSG_LEAVE_ROOM,
    MSG_USER_LIST, MSG_USER_JOIN, MSG_USER_LEAVE,
    MSG_CHAT, MSG_PING, MSG_PONG,
    MSG_STREAM_START, MSG_STREAM_STOP, MSG_ERROR,
    MSG_P2P_OFFER, MSG_P2P_ANSWER, MSG_P2P_ENDPOINT, MSG_RELAY_START,
    UDP_TYPE_AUDIO, UDP_TYPE_VIDEO,
    DEFAULT_PORT, DEFAULT_UDP_PORT,
)


def encode_tcp(msg_type: int, payload: dict) -> bytes:
    data = json.dumps(payload).encode("utf-8")
    return struct.pack("!II", msg_type, len(data)) + data


# ── Fragmentación ─────────────────────────────────────────────────────────────
# 1 400 bytes por chunk: conservador para no fragmentar a nivel IP en redes
# con MTU 1500 (Ethernet). Overhead por paquete: 1+4+2+2+2 = 11 bytes.
VIDEO_FRAG_SIZE   = 1400
VIDEO_FRAG_HEADER = struct.Struct("!HHH")   # seq, frag_idx, frag_total
MAX_FRAG_BUFS     = 128   # máx. frames incompletos en memoria por sender


# ── UDP P2P / Relay ───────────────────────────────────────────────────────────

class UDPMediaChannel:
    HOLE_PUNCH_TIMEOUT = 5.0

    def __init__(self):
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._running = False

        self.my_user_id: Optional[int] = None
        self.server_ip:  Optional[str] = None
        self.relay_port: int = DEFAULT_UDP_PORT

        self._peers: Dict[int, dict] = {}
        self._peers_lock = threading.Lock()

        self.on_audio: Optional[Callable] = None
        self.on_video: Optional[Callable] = None

        # Cola de decodificación de video: desacopla el hilo UDP del decode JPEG.
        # maxsize=1: si el consumidor va lento se descarta el frame viejo (no acumula latencia).
        import queue as _queue
        self._video_decode_q: _queue.Queue = _queue.Queue(maxsize=1)
        self._video_decode_thread: Optional[threading.Thread] = None

        # Reensamblaje: sender_id -> {seq -> {frag_idx -> bytes}}
        self._frag_bufs: Dict[int, Dict[int, Dict[int, bytes]]] = {}
        self._frag_lock  = threading.Lock()

        self._video_seq      = 0
        self._video_seq_lock = threading.Lock()

    def start(self, my_user_id: int, server_ip: str, relay_port: int):
        self.my_user_id = my_user_id
        self.server_ip  = server_ip
        self.relay_port = relay_port

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4 * 1024 * 1024)
        self._sock.bind(("0.0.0.0", 0))
        self._sock.settimeout(0.5)

        self._running = True
        self._thread  = threading.Thread(target=self._recv_loop, daemon=True)
        self._thread.start()
        self._video_decode_thread = threading.Thread(
            target=self._video_decode_loop, daemon=True
        )
        self._video_decode_thread.start()

        self._register_with_relay()
        log.info(f"Canal UDP iniciado (local port {self._sock.getsockname()[1]})")

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=2)
        if self._video_decode_thread:
            self._video_decode_thread.join(timeout=2)
        if self._sock:
            self._sock.close()
            self._sock = None
        with self._peers_lock:
            self._peers.clear()
        with self._frag_lock:
            self._frag_bufs.clear()

    def add_peer(self, peer_id: int, ip: str, port: int):
        with self._peers_lock:
            self._peers[peer_id] = {
                "addr":     (ip, port),
                "mode":     "p2p",
                "last_rx":  0.0,
                "added_at": time.monotonic(),
            }
        threading.Thread(
            target=self._hole_punch, args=(peer_id, ip, port), daemon=True
        ).start()
        log.info(f"Peer {peer_id} agregado: {ip}:{port} (intentando P2P)")

    def remove_peer(self, peer_id: int):
        with self._peers_lock:
            self._peers.pop(peer_id, None)
        with self._frag_lock:
            self._frag_bufs.pop(peer_id, None)

    # ── Envío ─────────────────────────────────────────────────────────────────

    def send_audio(self, opus_bytes: bytes):
        if not self._sock or not self.my_user_id:
            return
        packet = struct.pack("!BI", UDP_TYPE_AUDIO, self.my_user_id) + opus_bytes
        self._send_to_all(packet)

    def send_video(self, jpeg_bytes: bytes):
        """Fragmenta el JPEG y envía cada chunk como un datagrama UDP."""
        if not self._sock or not self.my_user_id:
            return

        with self._video_seq_lock:
            seq = self._video_seq
            self._video_seq = (self._video_seq + 1) % 65536

        chunks = [
            jpeg_bytes[i:i + VIDEO_FRAG_SIZE]
            for i in range(0, max(len(jpeg_bytes), 1), VIDEO_FRAG_SIZE)
        ]
        total = len(chunks)
        base  = struct.pack("!BI", UDP_TYPE_VIDEO, self.my_user_id)

        for idx, chunk in enumerate(chunks):
            frag_hdr = VIDEO_FRAG_HEADER.pack(seq, idx, total)
            self._send_to_all(base + frag_hdr + chunk)

    def _send_to_all(self, packet: bytes):
        with self._peers_lock:
            snapshot = list(self._peers.items())

        for peer_id, info in snapshot:
            try:
                if info["mode"] == "p2p":
                    self._sock.sendto(packet, info["addr"])
                else:
                    relay_data = struct.pack("!I", peer_id) + packet
                    self._sock.sendto(relay_data, (self.server_ip, self.relay_port))
            except Exception as e:
                log.debug(f"Error enviando a peer {peer_id}: {e}")

    # ── Recepción ─────────────────────────────────────────────────────────────

    def _recv_loop(self):
        while self._running:
            try:
                data, addr = self._sock.recvfrom(65535)
            except socket.timeout:
                self._check_relay_fallback()
                continue
            except Exception:
                if self._running:
                    log.error("Error en recv UDP", exc_info=True)
                break

            if len(data) < 5:
                continue

            pkt_type  = data[0]
            sender_id = struct.unpack("!I", data[1:5])[0]
            payload   = data[5:]

            is_from_relay = (
                addr[0] == self.server_ip and addr[1] == self.relay_port
            )
            with self._peers_lock:
                if sender_id in self._peers:
                    p = self._peers[sender_id]
                    p["last_rx"] = time.monotonic()
                    if not is_from_relay and p["mode"] != "p2p":
                        p["mode"] = "p2p"
                        p["addr"] = addr
                        log.info(f"P2P confirmado con peer {sender_id}")
                elif not is_from_relay:
                    self._peers[sender_id] = {
                        "addr":     addr,
                        "mode":     "p2p",
                        "last_rx":  time.monotonic(),
                        "added_at": time.monotonic(),
                    }
                    log.info(f"Peer {sender_id} auto-registrado por P2P entrante")

            if pkt_type == UDP_TYPE_AUDIO:
                # Ignorar paquetes propios (pueden llegar de vuelta via relay)
                if sender_id == self.my_user_id:
                    continue
                if self.on_audio:
                    self.on_audio(sender_id, payload)

            elif pkt_type == UDP_TYPE_VIDEO:
                # payload = [2B seq][2B frag_idx][2B frag_total][jpeg_chunk]
                if len(payload) < 6:
                    continue
                seq, frag_idx, frag_total = VIDEO_FRAG_HEADER.unpack_from(payload)
                chunk = payload[6:]

                if frag_total == 1:
                    jpeg = chunk
                else:
                    jpeg = self._reassemble(sender_id, seq, frag_idx, frag_total, chunk)

                if jpeg is not None:
                    # Encolar para decodificación en thread separado.
                    # put_nowait descarta el frame anterior si el consumidor va lento,
                    # garantizando latencia acotada (siempre se muestra el más reciente).
                    try:
                        self._video_decode_q.put_nowait((sender_id, jpeg))
                    except Exception:
                        pass  # cola llena → descartamos frame viejo

            elif pkt_type != 0x00:
                log.debug(f"Paquete UDP tipo desconocido {pkt_type:#x} de {sender_id}")

    def _reassemble(
        self, sender_id: int, seq: int,
        frag_idx: int, frag_total: int, chunk: bytes
    ) -> Optional[bytes]:
        with self._frag_lock:
            buf = self._frag_bufs.setdefault(sender_id, {})

            # Evitar memory leak: descartar frames muy viejos
            if len(buf) > MAX_FRAG_BUFS:
                oldest = min(buf.keys())
                del buf[oldest]

            frame = buf.setdefault(seq, {})
            frame[frag_idx] = chunk

            if len(frame) == frag_total:
                jpeg = b"".join(frame[i] for i in range(frag_total))
                del buf[seq]
                return jpeg

        return None

    def _video_decode_loop(self):
        """Hilo dedicado a decodificar frames JPEG y entregar al callback on_video.
        Corre separado del hilo UDP para no bloquear la recepción de paquetes."""
        import queue as _queue
        while self._running:
            try:
                sender_id, jpeg = self._video_decode_q.get(timeout=0.1)
                if self.on_video:
                    try:
                        self.on_video(sender_id, jpeg)
                    except Exception as e:
                        log.error(f"Error en on_video callback: {e}")
            except _queue.Empty:
                continue
            except Exception as e:
                if self._running:
                    log.error(f"Error en video decode loop: {e}")

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _hole_punch(self, peer_id: int, ip: str, port: int):
        punch = struct.pack("!BI", 0x00, self.my_user_id)
        for _ in range(5):
            try:
                self._sock.sendto(punch, (ip, port))
            except Exception:
                pass
            time.sleep(0.2)

    def _register_with_relay(self):
        if not self._sock or not self.server_ip or not self.my_user_id:
            return
        reg = struct.pack("!II", 0xFFFFFFFF, self.my_user_id)
        try:
            self._sock.sendto(reg, (self.server_ip, self.relay_port))
        except Exception as e:
            log.warning(f"No se pudo registrar en relay: {e}")

    def _check_relay_fallback(self):
        now = time.monotonic()
        with self._peers_lock:
            for peer_id, info in self._peers.items():
                if (info["mode"] == "p2p"
                        and info["last_rx"] == 0.0
                        and (now - info.get("added_at", now)) > self.HOLE_PUNCH_TIMEOUT):
                    info["mode"] = "relay"
                    log.info(f"Peer {peer_id}: sin P2P, usando relay")


# ── Conexión TCP al servidor ──────────────────────────────────────────────────

class ServerConnection:
    def __init__(self, host: str, port: int = DEFAULT_PORT, use_tls: bool = True):
        self.host    = host
        self.port    = port
        self.use_tls = use_tls

        self._reader: Optional[asyncio.StreamReader] = None
        self._writer: Optional[asyncio.StreamWriter] = None
        self._handlers: Dict[int, list] = {}
        self._running   = False
        self._connected = False
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        self.user_id:    Optional[int] = None
        self.username:   Optional[str] = None
        self.relay_port: int = DEFAULT_UDP_PORT

        self.udp: UDPMediaChannel = UDPMediaChannel()

    def on(self, msg_type: int, handler: Callable):
        self._handlers.setdefault(msg_type, []).append(handler)

    def off(self, msg_type: int, handler: Callable):
        if msg_type in self._handlers:
            try:
                self._handlers[msg_type].remove(handler)
            except ValueError:
                pass

    async def connect(self, username: str, password: str) -> Tuple[bool, str]:
        self._loop = asyncio.get_event_loop()

        ssl_ctx = None
        if self.use_tls:
            here    = Path(__file__).parent
            ca_path = here / "ca.crt"
            if not ca_path.exists():
                ca_path = here / "certs" / "ca.crt"
            ssl_ctx = self._build_ssl_ctx(ca_path if ca_path.exists() else None)

        try:
            self._reader, self._writer = await asyncio.wait_for(
                asyncio.open_connection(self.host, self.port, ssl=ssl_ctx),
                timeout=10.0,
            )
        except asyncio.TimeoutError:
            return False, "Timeout al conectar"
        except ConnectionRefusedError:
            return False, "Conexión rechazada — ¿está el servidor corriendo?"
        except ssl.SSLError as e:
            return False, (
                f"Error TLS: {e}\n"
                "Importá ca.crt en Windows:\n"
                "doble clic → Instalar → Equipo local → "
                "'Entidades de certificación raíz de confianza'"
            )
        except Exception as e:
            return False, f"Error de conexión: {e}"

        await self._send_raw(MSG_AUTH, {"username": username, "password": password})

        try:
            msg_type, payload = await asyncio.wait_for(
                self._read_one(), timeout=10.0
            )
        except asyncio.TimeoutError:
            return False, "Timeout esperando respuesta del servidor"

        if msg_type == MSG_AUTH_FAIL:
            return False, payload.get("reason", "Autenticación fallida")

        if msg_type == MSG_AUTH_OK:
            self.user_id    = payload["user_id"]
            self.username   = payload["username"]
            self.relay_port = payload.get("relay_port", DEFAULT_UDP_PORT)
            self._running   = True
            self._connected = True

            self.udp.start(self.user_id, self.host, self.relay_port)
            asyncio.create_task(self._read_loop())
            log.info(f"Conectado como {self.username} (id={self.user_id})")
            return True, "OK"

        return False, "Respuesta inesperada del servidor"

    async def disconnect(self):
        self._running   = False
        self._connected = False
        self.udp.stop()
        if self._writer:
            try:
                self._writer.close()
                await self._writer.wait_closed()
            except Exception:
                pass

    async def join_room(self, room_id: str):
        await self._send_raw(MSG_JOIN_ROOM, {"room_id": room_id})

    async def leave_room(self):
        await self._send_raw(MSG_LEAVE_ROOM, {})

    async def send_chat(self, text: str):
        await self._send_raw(MSG_CHAT, {"text": text})

    async def send_stream_start(self, stream_type: str):
        await self._send_raw(MSG_STREAM_START, {"type": stream_type})

    async def send_stream_stop(self):
        await self._send_raw(MSG_STREAM_STOP, {})

    async def ping(self):
        await self._send_raw(MSG_PING, {"ts": int(time.time() * 1000)})

    def send_audio_udp(self, opus_bytes: bytes):
        self.udp.send_audio(opus_bytes)

    def send_video_udp(self, jpeg_bytes: bytes):
        self.udp.send_video(jpeg_bytes)

    async def send_audio_frame(self, opus_bytes: bytes):
        self.send_audio_udp(opus_bytes)

    async def send_video_frame(self, jpeg_bytes: bytes):
        self.send_video_udp(jpeg_bytes)

    @property
    def is_connected(self) -> bool:
        return self._connected

    @staticmethod
    def _build_ssl_ctx(ca_cert_path: Optional[Path]) -> ssl.SSLContext:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        if ca_cert_path and ca_cert_path.exists():
            ctx.load_verify_locations(str(ca_cert_path))
            ctx.verify_mode = ssl.CERT_REQUIRED
            log.info(f"TLS: CA {ca_cert_path}")
        else:
            ctx.verify_mode = ssl.CERT_NONE
            log.warning("TLS: sin verificación de CA")
        return ctx

    async def _send_raw(self, msg_type: int, payload: dict):
        if not self._writer:
            return
        try:
            self._writer.write(encode_tcp(msg_type, payload))
            await self._writer.drain()
        except Exception as e:
            log.error(f"Error TCP send: {e}")
            await self._handle_disconnect()

    async def _read_one(self):
        header = await self._reader.readexactly(8)
        msg_type, length = struct.unpack("!II", header)
        data = await self._reader.readexactly(length)
        return msg_type, json.loads(data.decode("utf-8"))

    async def _read_loop(self):
        while self._running:
            try:
                msg_type, payload = await self._read_one()
                await self._dispatch(msg_type, payload)
            except asyncio.IncompleteReadError:
                log.info("Servidor cerró la conexión")
                break
            except Exception as e:
                log.error(f"Error en read loop: {e}", exc_info=True)
                break
        await self._handle_disconnect()

    async def _dispatch(self, msg_type: int, payload: dict):
        if msg_type == MSG_P2P_ENDPOINT:
            peer_id   = payload.get("user_id")
            peer_ip   = payload.get("ip")
            peer_port = payload.get("port")
            if peer_id and peer_ip and peer_port:
                self.udp.add_peer(peer_id, peer_ip, peer_port)
        elif msg_type == MSG_RELAY_START:
            log.info("Servidor indica usar relay para media")

        for h in self._handlers.get(msg_type, []):
            try:
                if asyncio.iscoroutinefunction(h):
                    await h(payload)
                else:
                    h(payload)
            except Exception as e:
                log.error(f"Error en handler: {e}", exc_info=True)

    def set_media_callbacks(self, on_audio: Callable, on_video: Callable):
        """Registrar callbacks DESPUÉS de connect() para que udp.start() ya haya corrido."""
        self.udp.on_audio = on_audio
        self.udp.on_video = on_video
        log.info("Callbacks de media UDP registrados")

    async def _handle_disconnect(self):
        if self._connected:
            self._connected = False
            self._running   = False
            self.udp.stop()
            log.warning("Desconectado del servidor")
            await self._dispatch(MSG_ERROR, {"reason": "Desconectado del servidor"})
