"""
Configuración persistente del cliente.
Guarda ajustes en %APPDATA%/FranBle/config.json (Windows)
"""

import json
import logging
import os
from pathlib import Path
from typing import Any

log = logging.getLogger("config")

APP_NAME = "FranBle"


def get_config_dir() -> Path:
    if os.name == "nt":  # Windows
        base = Path(os.environ.get("APPDATA", Path.home()))
    else:  # Linux (desarrollo)
        base = Path.home() / ".config"
    d = base / APP_NAME
    d.mkdir(parents=True, exist_ok=True)
    return d


CONFIG_PATH = get_config_dir() / "config.json"

DEFAULTS = {
    # Servidor
    "last_host": "",
    "last_port": 64730,
    "last_username": "",
    "use_tls": True,

    # Audio
    "input_device": -1,       # -1 = dispositivo por defecto
    "output_device": -1,
    "input_volume": 100,      # 0-200 %
    "output_volume": 100,
    "vad_threshold": 500,     # energía RMS mínima
    "push_to_talk": False,
    "ptt_key": "F1",

    # Video
    "default_quality": "720p",
    "camera_device": 0,
    "fps": 30,
    "screen_monitor": 0,      # índice de monitor para captura

    # UI
    "window_geometry": None,
    "window_state": None,
    "splitter_state": None,
}


class Config:
    """
    Configuración simple con persistencia JSON.

    Uso:
        cfg = Config()
        cfg.load()
        host = cfg.get("last_host")
        cfg.set("last_host", "192.168.1.10")
        cfg.save()
    """

    def __init__(self):
        self._data: dict = dict(DEFAULTS)

    def load(self):
        if CONFIG_PATH.exists():
            try:
                with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                    stored = json.load(f)
                # Mezclar con defaults (keys nuevas en defaults no están en el archivo)
                self._data = {**DEFAULTS, **stored}
                log.info(f"Config cargada desde {CONFIG_PATH}")
            except Exception as e:
                log.warning(f"Error cargando config: {e} — usando defaults")
                self._data = dict(DEFAULTS)
        else:
            log.info("Config no encontrada, usando valores por defecto")

    def save(self):
        try:
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            log.error(f"Error guardando config: {e}")

    def get(self, key: str, fallback: Any = None) -> Any:
        return self._data.get(key, fallback if fallback is not None else DEFAULTS.get(key))

    def set(self, key: str, value: Any):
        self._data[key] = value

    def reset(self):
        self._data = dict(DEFAULTS)
        self.save()


# Instancia global
config = Config()
