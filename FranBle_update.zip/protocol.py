"""
Constantes de protocolo FranBle.
"""

# ── Mensajes TCP (control y señalización) ─────────────────────────────────────
MSG_AUTH          = 0x01
MSG_AUTH_OK       = 0x02
MSG_AUTH_FAIL     = 0x03
MSG_ROOM_LIST     = 0x04
MSG_JOIN_ROOM     = 0x05
MSG_LEAVE_ROOM    = 0x06
MSG_USER_LIST     = 0x07
MSG_USER_JOIN     = 0x08
MSG_USER_LEAVE    = 0x09
MSG_CHAT          = 0x0A
MSG_PING          = 0x0B
MSG_PONG          = 0x0C
MSG_STREAM_START  = 0x13
MSG_STREAM_STOP   = 0x14
MSG_STREAM_LOCKED = 0x15
MSG_ERROR         = 0xFF

# Señalización P2P (via TCP al servidor, que los reenvía)
MSG_P2P_OFFER     = 0x30   # C→S→C  oferta de conexión P2P
MSG_P2P_ANSWER    = 0x31   # C→S→C  respuesta
MSG_P2P_ENDPOINT  = 0x32   # S→C    IP:puerto UDP del otro cliente
MSG_RELAY_START   = 0x33   # S→C    indica usar relay

# ── Media (UDP, P2P o relay) ──────────────────────────────────────────────────
# Los frames viajan por UDP entre clientes (NO por TCP al servidor).
# Formato UDP: [1 byte tipo][4 bytes user_id BE][N bytes payload]
UDP_TYPE_AUDIO    = 0x01   # payload = Opus bytes crudos
UDP_TYPE_VIDEO    = 0x02   # payload = JPEG bytes crudos

# ── Tipos de stream ────────────────────────────────────────────────────────────
STREAM_CAMERA = "camera"
STREAM_SCREEN = "screen"
STREAM_FILE   = "file"

# ── Configuración ─────────────────────────────────────────────────────────────
DEFAULT_PORT     = 64730
DEFAULT_UDP_PORT = 64731
