"""
Módulo de audio del cliente FranBle.

Captura → Opus → UDP directo al peer (P2P o relay mínimo).
Recibe → UDP → decodifica Opus → reproduce.

El celular NO toca estos bytes.
"""

import logging
import struct
import threading
from typing import Callable, Optional

log = logging.getLogger("audio")

try:
    import sounddevice as sd
    import numpy as np
    SD_OK = True
except ImportError:
    SD_OK = False
    log.warning("sounddevice no instalado — audio desactivado")

try:
    import opuslib
    OPUS_OK = True
except Exception:
    opuslib = None
    OPUS_OK = False
    log.warning("opuslib no instalado — usando PCM sin comprimir")

SAMPLE_RATE      = 48000
CHANNELS         = 2   # estéreo — micrófono y loopback usan el mismo formato
CHUNK_MS         = 20
CHUNK_SAMPLES    = int(SAMPLE_RATE * CHUNK_MS / 1000)   # 960
DTYPE            = "int16"
FRAME_BYTES      = CHUNK_SAMPLES * CHANNELS * 2  # bytes por frame PCM estéreo
VAD_THRESHOLD    = 500
VAD_HOLD_FRAMES  = 8
MAX_BUFFER_FRAMES = 5   # ~100 ms; evita acumulación de latencia


class AudioCapture:
    """
    Captura el micrófono y entrega frames Opus al callback on_frame.
    El callback debe llamar a conn.send_audio_udp(opus_bytes).
    """

    def __init__(
        self,
        on_frame: Callable[[bytes], None],
        device: int = None,
        vad_threshold: int = VAD_THRESHOLD,
        volume: int = 100,
    ):
        self.on_frame      = on_frame
        self.device        = device
        self._running      = False
        self._thread: Optional[threading.Thread] = None
        self._muted        = False
        self._vad_silent   = 0
        self._vad_threshold = vad_threshold
        self._volume       = volume
        self._last_rms     = 0.0

        if OPUS_OK:
            self._encoder = opuslib.Encoder(
                SAMPLE_RATE, CHANNELS, opuslib.APPLICATION_VOIP
            )
            self._encoder.bitrate = 64000   # 64 kbps estéreo (era 32 mono)

    def start(self):
        if not SD_OK:
            log.error("sounddevice no disponible")
            return
        self._running = True
        self._thread = threading.Thread(target=self._capture_loop, daemon=True)
        self._thread.start()
        log.info(f"Captura de audio iniciada (device={self.device}, vol={self._volume}%)")

    def stop(self):
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)

    def set_muted(self, muted: bool):
        self._muted = muted

    def set_volume(self, volume: int):
        self._volume = max(0, min(200, volume))

    def _capture_loop(self):
        try:
            with sd.InputStream(
                samplerate=SAMPLE_RATE,
                channels=CHANNELS,
                dtype=DTYPE,
                blocksize=CHUNK_SAMPLES,
                device=self.device,
            ) as stream:
                while self._running:
                    data, _ = stream.read(CHUNK_SAMPLES)

                    if self._muted:
                        continue

                    # Aplicar volumen
                    if self._volume != 100:
                        gain = self._volume / 100.0
                        arr  = np.frombuffer(data.tobytes(), dtype=np.int16).astype(np.float32)
                        arr  = np.clip(arr * gain, -32768, 32767).astype(np.int16)
                        pcm  = arr.tobytes()
                    else:
                        pcm = data.tobytes()

                    # VAD
                    if not self._has_voice(pcm):
                        self._vad_silent += 1
                        if self._vad_silent > VAD_HOLD_FRAMES:
                            continue
                    else:
                        self._vad_silent = 0

                    # Codificar y entregar
                    if OPUS_OK:
                        try:
                            frame = self._encoder.encode(pcm, CHUNK_SAMPLES)
                            self.on_frame(frame)
                        except Exception as e:
                            log.error(f"Opus encode: {e}")
                    else:
                        self.on_frame(pcm)

        except Exception as e:
            log.error(f"Error en captura de audio: {e}")

    def _has_voice(self, pcm: bytes) -> bool:
        samples = struct.unpack(f"{len(pcm)//2}h", pcm)
        if not samples:
            self._last_rms = 0.0
            return False
        rms = (sum(s * s for s in samples) / len(samples)) ** 0.5
        self._last_rms = rms
        return rms > self._vad_threshold


class AudioPlayback:
    """
    Recibe frames Opus de múltiples usuarios y los reproduce mezclados.
    Los frames llegan directamente del canal UDP, sin pasar por el servidor.
    """

    def __init__(self, device: int = None, volume: int = 100):
        self.device   = device
        self._volume  = volume
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._buffers: dict = {}
        self._lock    = threading.Lock()
        self._deafened = False

        if OPUS_OK:
            self._decoders: dict = {}

    def start(self):
        if not SD_OK:
            return
        self._running = True
        self._thread = threading.Thread(target=self._playback_loop, daemon=True)
        self._thread.start()
        log.info(f"Reproducción de audio iniciada (device={self.device}, vol={self._volume}%)")

    def stop(self):
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)

    def push_frame(self, user_id: int, opus_bytes: bytes):
        """Llamar cuando llega un frame de audio UDP de un peer."""
        if self._deafened:
            return
        with self._lock:
            if user_id not in self._buffers:
                self._buffers[user_id] = []
                if OPUS_OK:
                    self._decoders[user_id] = opuslib.Decoder(SAMPLE_RATE, CHANNELS)
            buf = self._buffers[user_id]
            buf.append(opus_bytes)
            # Limitar buffer para evitar audio retrasado
            while len(buf) > MAX_BUFFER_FRAMES:
                buf.pop(0)

    def remove_user(self, user_id: int):
        with self._lock:
            self._buffers.pop(user_id, None)
            if OPUS_OK:
                self._decoders.pop(user_id, None)

    def set_deafened(self, deafened: bool):
        self._deafened = deafened

    def set_volume(self, volume: int):
        self._volume = max(0, min(200, volume))

    def _playback_loop(self):
        try:
            with sd.OutputStream(
                samplerate=SAMPLE_RATE,
                channels=CHANNELS,
                dtype=DTYPE,
                blocksize=CHUNK_SAMPLES,
                device=self.device,
            ) as stream:
                while self._running:
                    mixed = self._mix_frames()
                    if mixed:
                        arr = np.frombuffer(mixed, dtype=np.int16)
                        if self._volume != 100:
                            gain = self._volume / 100.0
                            arr  = np.clip(
                                arr.astype(np.float32) * gain, -32768, 32767
                            ).astype(np.int16)
                        arr = arr.reshape(-1, CHANNELS)
                    else:
                        arr = np.zeros((CHUNK_SAMPLES, CHANNELS), dtype=np.int16)
                    stream.write(arr)
        except Exception as e:
            log.error(f"Error en reproducción: {e}")

    def _mix_frames(self) -> Optional[bytes]:
        frames = []
        with self._lock:
            for user_id, buf in list(self._buffers.items()):
                if OPUS_OK and user_id in self._decoders:
                    frame_bytes = buf.pop(0) if buf else None
                    try:
                        pcm = self._decoders[user_id].decode(frame_bytes, CHUNK_SAMPLES)
                        frames.append(pcm)
                    except Exception:
                        pass
                elif buf:
                    frames.append(buf.pop(0))

        if not frames:
            return None
        if len(frames) == 1:
            return frames[0]

        n_samples = CHUNK_SAMPLES * CHANNELS   # total de shorts en un frame estéreo
        fmt = f"{n_samples}h"
        mix = [0] * n_samples
        for f in frames:
            try:
                samples = struct.unpack(fmt, f[:n_samples * 2])
                for i, s in enumerate(samples):
                    mix[i] += s
            except Exception:
                pass

        mix = [max(-32768, min(32767, s)) for s in mix]
        return struct.pack(fmt, *mix)


def list_audio_devices() -> tuple:
    """Retorna (inputs, outputs) filtrando virtuales y duplicados."""
    inputs  = [(-1, "Dispositivo por defecto (micrófono)")]
    outputs = [(-1, "Dispositivo por defecto (altavoces)")]

    if not SD_OK:
        return inputs, outputs

    VIRTUAL = [
        "mapper", "primary", "microsoft sound mapper",
        "stereo mix", "what u hear", "wave out mix",
        "loopback", "virtual", "cable", "vb-audio",
        "voicemeeter", "blackhole", "null output",
    ]

    def is_virtual(name: str) -> bool:
        n = name.lower()
        return any(k in n for k in VIRTUAL)

    try:
        seen_in  = set()
        seen_out = set()
        for i, dev in enumerate(sd.query_devices()):
            name = dev["name"].strip()
            base = name.lower()
            if dev["max_input_channels"] > 0 and not is_virtual(name):
                if base not in seen_in:
                    seen_in.add(base)
                    inputs.append((i, name))
            if dev["max_output_channels"] > 0 and not is_virtual(name):
                if base not in seen_out:
                    seen_out.add(base)
                    outputs.append((i, name))
    except Exception as e:
        log.warning(f"Error listando dispositivos: {e}")

    return inputs, outputs
