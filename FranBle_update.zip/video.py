"""
Módulo de video del cliente FranBle.

Captura → JPEG → UDP P2P directo al peer (o relay mínimo).
Recibe → UDP → decodifica JPEG → muestra en UI.

El celular NO toca estos bytes.
"""

import asyncio
import logging
import queue
import threading
import time
from enum import Enum
from typing import Callable, Optional

log = logging.getLogger("video")

try:
    import cv2
    import numpy as np
    CV2_OK = True
except ImportError:
    CV2_OK = False
    log.warning("opencv-python no instalado — video desactivado")

QUALITIES = {
    "2K":    (2560, 1440),
    "1080p": (1920, 1080),
    "720p":  (1280, 720),
    "480p":  (854,  480),
}

JPEG_QUALITY = 65   # balance calidad/ancho de banda para UDP


class VideoSource(Enum):
    CAMERA = "camera"
    SCREEN = "screen"
    WINDOW = "window"
    REGION = "region"
    FILE   = "file"


def list_windows() -> list:
    import sys
    windows = []
    if sys.platform == "win32":
        try:
            import ctypes, ctypes.wintypes
            EnumWindows          = ctypes.windll.user32.EnumWindows
            IsWindowVisible      = ctypes.windll.user32.IsWindowVisible
            GetWindowTextW       = ctypes.windll.user32.GetWindowTextW
            GetWindowTextLengthW = ctypes.windll.user32.GetWindowTextLengthW
            GetWindowRect        = ctypes.windll.user32.GetWindowRect
            WNDENUMPROC = ctypes.WINFUNCTYPE(
                ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM
            )

            def _cb(hwnd, _):
                if not IsWindowVisible(hwnd):
                    return True
                length = GetWindowTextLengthW(hwnd)
                if not length:
                    return True
                buf = ctypes.create_unicode_buffer(length + 1)
                GetWindowTextW(hwnd, buf, length + 1)
                title = buf.value.strip()
                if not title or title in ("Program Manager", "Windows Input Experience"):
                    return True
                rect = ctypes.wintypes.RECT()
                GetWindowRect(hwnd, ctypes.byref(rect))
                w = rect.right - rect.left
                h = rect.bottom - rect.top
                if w < 50 or h < 50:
                    return True
                windows.append({
                    "title": title, "hwnd": hwnd,
                    "rect":  (rect.left, rect.top, w, h),
                })
                return True

            EnumWindows(WNDENUMPROC(_cb), 0)
        except Exception as e:
            log.warning(f"list_windows win32: {e}")

    elif sys.platform.startswith("linux"):
        try:
            import subprocess
            out = subprocess.check_output(
                ["wmctrl", "-lG"], text=True, stderr=subprocess.DEVNULL
            )
            for line in out.splitlines():
                parts = line.split(None, 9)
                if len(parts) < 9:
                    continue
                wid = int(parts[0], 16)
                x, y, w, h = int(parts[2]), int(parts[3]), int(parts[4]), int(parts[5])
                title = parts[8].strip()
                if title and title != "N/A" and w >= 50 and h >= 50:
                    windows.append({"title": title, "wid": wid, "rect": (x, y, w, h)})
        except Exception as e:
            log.warning(f"list_windows linux: {e}")

    return windows


def _precise_sleep(target: float):
    remaining = target - time.perf_counter()
    if remaining <= 0:
        return
    if remaining > 0.002:
        time.sleep(remaining - 0.001)
    while time.perf_counter() < target:
        pass


class VideoManager:
    """
    Gestiona la fuente de video activa.

    Los frames se envían directamente al peer via UDP (conn.send_video_udp),
    sin pasar por el servidor.
    """

    def __init__(self, server_conn, quality: str = "720p", audio_playback=None):
        self.server_conn    = server_conn
        self.quality        = quality
        self._audio_playback = audio_playback  # AudioPlayback; se silencia durante loopback
        self._source:  Optional[VideoSource] = None
        self._running  = False
        self._thread:  Optional[threading.Thread] = None
        self._cap      = None
        self._file_path: Optional[str] = None
        self._window_handle = None
        self._window_rect   = None
        self._region: Optional[tuple] = None

        # Callback: on_remote_frame(user_id, frame_bgr_numpy)
        self.on_remote_frame: Optional[Callable] = None

        # Captura de audio del sistema (loopback) para screen/window/file share.
        # Se activa automáticamente al transmitir esas fuentes.
        self._loopback_thread: Optional[threading.Thread] = None
        self._loopback_running = False

    # ── Iniciar ───────────────────────────────────────────────────────────────

    async def start_camera(self, quality: str = None):
        if quality:
            self.quality = quality
        await self._start(VideoSource.CAMERA)

    async def start_screen(self, quality: str = None):
        if quality:
            self.quality = quality
        await self._start(VideoSource.SCREEN)

    async def start_window(self, handle, rect: tuple = None, quality: str = None):
        if quality:
            self.quality = quality
        self._window_handle = handle
        self._window_rect   = rect
        await self._start(VideoSource.WINDOW)

    async def start_region(self, x: int, y: int, w: int, h: int, quality: str = None):
        if quality:
            self.quality = quality
        self._region = (x, y, w, h)
        await self._start(VideoSource.REGION)

    async def start_file(self, filepath: str, quality: str = None):
        if quality:
            self.quality = quality
        self._file_path = filepath
        await self._start(VideoSource.FILE)

    async def stop(self):
        self._running = False
        # Detener loopback de audio del sistema y restaurar reproducción local
        self._loopback_running = False
        if self._loopback_thread:
            self._loopback_thread.join(timeout=2)
            self._loopback_thread = None
        if self._audio_playback:
            self._audio_playback.set_deafened(False)
        if self._thread:
            self._thread.join(timeout=3)
            self._thread = None
        if self._cap:
            self._cap.release()
            self._cap = None
        self._source = None
        await self.server_conn.send_stream_stop()
        log.info("Transmisión de video detenida")

    async def _start(self, source: VideoSource):
        if self._running:
            await self.stop()
        if not CV2_OK:
            log.error("opencv-python no disponible")
            return
        self._source  = source
        self._running = True
        self._thread  = threading.Thread(target=self._capture_loop, daemon=True)
        self._thread.start()
        # Captura de audio del sistema para fuentes no-micrófono
        if source in (VideoSource.SCREEN, VideoSource.WINDOW, VideoSource.REGION, VideoSource.FILE):
            self._start_loopback()
        await self.server_conn.send_stream_start(source.value)
        log.info(f"Stream iniciado: {source.value} @ {self.quality}")

    # ── Captura de audio del sistema (loopback) ───────────────────────────────

    def _start_loopback(self):
        """
        Captura el audio que está reproduciendo Windows (WASAPI loopback)
        y lo envía por el canal UDP de audio igual que el micrófono.

        Mientras el loopback está activo, silencia AudioPlayback localmente:
        si no lo hacemos, pyaudiowpatch capturaría el audio remoto reproducido
        por los parlantes, creando un eco y acumulando copias del mismo audio.
        """
        # Silenciar reproducción local para evitar que el loopback la recapture
        if self._audio_playback:
            self._audio_playback.set_deafened(True)
        self._loopback_running = True
        self._loopback_thread = threading.Thread(
            target=self._loopback_loop, daemon=True
        )
        self._loopback_thread.start()
        log.info("Captura de audio del sistema (loopback) iniciada")

    def _loopback_loop(self):
        """
        Captura el audio del sistema (loopback) y lo envía por UDP.

        Estrategias en orden de preferencia:
          1. pyaudiowpatch  — fork de PyAudio con WASAPI loopback nativo (Windows)
          2. sounddevice    — dispositivo "[Loopback]" explícito por nombre
          3. sounddevice    — WasapiSettings(loopback=True) sobre output por defecto
        Si ninguna funciona, sale sin error fatal.
        """
        RATE     = 48000
        CHANNELS = 2
        CHUNK    = 960   # 20 ms a 48 kHz

        # Preparar encoder Opus
        use_opus  = False
        encoder   = None
        try:
            import opuslib as _opuslib
            encoder  = _opuslib.Encoder(RATE, CHANNELS, _opuslib.APPLICATION_AUDIO)
            encoder.bitrate = 96000
            use_opus = True
        except Exception:
            pass

        def _send(pcm_bytes: bytes):
            if use_opus and encoder:
                try:
                    self.server_conn.send_audio_udp(encoder.encode(pcm_bytes, CHUNK))
                except Exception as e:
                    log.debug(f"Loopback opus encode: {e}")
            else:
                self.server_conn.send_audio_udp(pcm_bytes)

        # ── Estrategia 1: pyaudiowpatch ───────────────────────────────────────
        try:
            import pyaudiowpatch as pyaudio
            pa = pyaudio.PyAudio()
            try:
                # Obtener el dispositivo de loopback del output por defecto
                default_speakers = pa.get_default_wasapi_loopback()
                log.info(
                    f"Loopback (pyaudiowpatch): '{default_speakers['name']}' "
                    f"ch={default_speakers['maxInputChannels']} "
                    f"rate={int(default_speakers['defaultSampleRate'])}"
                )
                # pyaudiowpatch puede tener una tasa nativa distinta de 48000
                native_rate = int(default_speakers["defaultSampleRate"])
                native_ch   = min(default_speakers["maxInputChannels"], 2)
                native_chunk = int(native_rate * 0.02)  # 20 ms

                stream = pa.open(
                    format=pyaudio.paInt16,
                    channels=native_ch,
                    rate=native_rate,
                    frames_per_buffer=native_chunk,
                    input=True,
                    input_device_index=default_speakers["index"],
                )
                log.info("Loopback activo (pyaudiowpatch)")
                try:
                    import numpy as _np
                    import audioop as _audioop
                    _numpy_ok = True
                except ImportError:
                    _numpy_ok = False

                try:
                    while self._loopback_running:
                        try:
                            raw = stream.read(native_chunk, exception_on_overflow=False)
                        except Exception as e:
                            log.debug(f"Loopback read: {e}")
                            continue

                        # Normalizar a 48000 Hz estéreo si hace falta
                        pcm = raw
                        if native_ch == 1 and CHANNELS == 2:
                            if _numpy_ok:
                                arr = _np.frombuffer(pcm, dtype=_np.int16)
                                pcm = _np.repeat(arr[:, None], 2, axis=1).flatten().tobytes()
                            else:
                                import audioop
                                pcm = audioop.tostereo(pcm, 2, 1)
                        if native_rate != RATE:
                            import audioop
                            pcm, _ = audioop.ratecv(
                                pcm, 2, CHANNELS, native_rate, RATE, None
                            )
                        expected = CHUNK * CHANNELS * 2
                        if len(pcm) < expected:
                            pcm = pcm + b"\x00" * (expected - len(pcm))
                        elif len(pcm) > expected:
                            pcm = pcm[:expected]

                        _send(pcm)
                finally:
                    stream.stop_stream()
                    stream.close()
            finally:
                pa.terminate()
            return  # éxito con pyaudiowpatch

        except ImportError:
            log.info("pyaudiowpatch no instalado — probando sounddevice")
        except Exception as e:
            log.warning(f"Loopback (pyaudiowpatch) falló: {e} — probando sounddevice")

        # ── Estrategias 2 y 3: sounddevice ───────────────────────────────────
        try:
            import sounddevice as sd
            import numpy as _np
        except ImportError:
            log.warning("sounddevice no disponible — sin audio del sistema")
            return

        device_arg     = None
        extra_settings = None

        # Estrategia 2: dispositivo "[Loopback]" explícito
        try:
            for i, dev in enumerate(sd.query_devices()):
                if (dev["max_input_channels"] >= 1
                        and "loopback" in dev["name"].lower()):
                    device_arg = i
                    log.info(
                        f"Loopback (sounddevice explicit): idx={i} '{dev['name']}'"
                    )
                    break
        except Exception:
            pass

        # Estrategia 3: WasapiSettings sobre output por defecto
        if device_arg is None:
            try:
                extra_settings  = sd.WasapiSettings(loopback=True)
                default_out_idx = sd.default.device[1]
                if default_out_idx is None or default_out_idx < 0:
                    raise RuntimeError("No hay dispositivo de salida por defecto")
                device_arg = default_out_idx
                log.info(
                    f"Loopback (sounddevice WasapiSettings): output idx={device_arg}"
                )
            except AttributeError:
                log.warning(
                    "sounddevice sin WasapiSettings y sin dispositivo loopback explícito.\n"
                    "  → Instalá pyaudiowpatch para audio del sistema:  pip install pyaudiowpatch"
                )
                return
            except Exception as e:
                log.warning(f"Loopback sounddevice setup falló: {e}")
                return

        try:
            stream_kwargs = dict(
                samplerate=RATE,
                channels=CHANNELS,
                dtype="int16",
                blocksize=CHUNK,
                device=device_arg,
            )
            if extra_settings is not None:
                stream_kwargs["extra_settings"] = extra_settings

            with sd.InputStream(**stream_kwargs) as stream:
                log.info(f"Loopback activo (sounddevice, device={device_arg})")
                while self._loopback_running:
                    data, overflowed = stream.read(CHUNK)
                    if overflowed:
                        log.debug("Loopback: overflow — frame descartado")
                        continue
                    _send(data.tobytes())

        except Exception as e:
            log.warning(
                f"Loopback de audio no disponible: {e}\n"
                f"  → Instalá pyaudiowpatch para audio del sistema:  pip install pyaudiowpatch"
            )

    # ── Recepción desde UDP ───────────────────────────────────────────────────

    def receive_frame(self, user_id: int, jpeg_bytes: bytes):
        """
        Llamar cuando llega un frame de video UDP de un peer.
        Decodifica el JPEG y llama a on_remote_frame.
        """
        if not CV2_OK or not self.on_remote_frame:
            return
        try:
            arr   = np.frombuffer(jpeg_bytes, dtype=np.uint8)
            frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            if frame is not None:
                self.on_remote_frame(user_id, frame)
        except Exception as e:
            log.error(f"Error decodificando frame: {e}")

    # ── Loop de captura ───────────────────────────────────────────────────────

    def _capture_loop(self):
        w, h  = QUALITIES.get(self.quality, (1280, 720))
        fps   = 30
        delay = 1.0 / fps

        # ── Inicializar fuente ────────────────────────────────────────────────
        if self._source == VideoSource.CAMERA:
            self._cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
            self._cap.set(cv2.CAP_PROP_FRAME_WIDTH,  w)
            self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
            self._cap.set(cv2.CAP_PROP_FPS, fps)

        elif self._source in (VideoSource.SCREEN, VideoSource.WINDOW, VideoSource.REGION):
            try:
                import mss
                self._screen_mss = mss.mss()
                if self._source == VideoSource.SCREEN:
                    m = self._screen_mss.monitors[1]
                    self._screen_mon = {
                        "top":    m["top"],  "left":   m["left"],
                        "width":  min(w, m["width"]),
                        "height": min(h, m["height"]),
                    }
                elif self._source == VideoSource.REGION:
                    rx, ry, rw, rh = self._region
                    self._screen_mon = {"top": ry, "left": rx, "width": rw, "height": rh}
                self._cap = None
            except ImportError:
                log.error("mss no instalado")
                self._running = False
                return

        elif self._source == VideoSource.FILE:
            self._cap = cv2.VideoCapture(self._file_path)
            if not self._cap.isOpened():
                log.error(f"No se pudo abrir: {self._file_path}")
                self._running = False
                return
            fps   = self._cap.get(cv2.CAP_PROP_FPS) or 30
            delay = 1.0 / fps

        encode_params = [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY]

        # Cola de envío desacoplada (1 frame máximo para no acumular latencia)
        send_q: queue.Queue = queue.Queue(maxsize=1)

        def _sender():
            while self._running:
                try:
                    jpeg_bytes, frame = send_q.get(timeout=0.1)
                    # Preview local (user_id = -1)
                    if self.on_remote_frame:
                        self.on_remote_frame(-1, frame)
                    # Enviar por UDP directo al peer
                    self.server_conn.send_video_udp(jpeg_bytes)
                except queue.Empty:
                    continue
                except Exception as e:
                    log.error(f"Sender error: {e}")

        sender_thread = threading.Thread(target=_sender, daemon=True)
        sender_thread.start()

        # Timer preciso (Windows)
        import ctypes as _ct
        _winmm = False
        try:
            _ct.windll.winmm.timeBeginPeriod(1)
            _winmm = True
        except Exception:
            pass

        t_next = time.perf_counter()

        while self._running:
            frame = self._grab(w, h)
            if frame is None:
                if self._source == VideoSource.FILE:
                    break
                t_next += delay
                _precise_sleep(t_next)
                continue

            ok, buf = cv2.imencode(".jpg", frame, encode_params)
            if ok:
                try:
                    send_q.put_nowait((buf.tobytes(), frame))
                except queue.Full:
                    pass  # descartamos frame, mantenemos ritmo

            t_next += delay
            _precise_sleep(t_next)

        if _winmm:
            try:
                _ct.windll.winmm.timeEndPeriod(1)
            except Exception:
                pass
        if self._cap:
            self._cap.release()
            self._cap = None

    def _grab(self, w: int, h: int):
        if self._source in (VideoSource.SCREEN, VideoSource.REGION):
            return self._grab_mss(self._screen_mon, w, h)

        if self._source == VideoSource.WINDOW:
            import sys
            if sys.platform == "win32":
                return self._grab_window_win32(self._window_handle, w, h)
            else:
                rect = self._window_rect
                if rect is None:
                    return None
                wx, wy, ww, wh = rect
                mon = {"top": wy, "left": wx, "width": max(ww, 1), "height": max(wh, 1)}
                return self._grab_mss(mon, w, h)

        if self._cap:
            ret, frame = self._cap.read()
            if not ret:
                return None
            if frame.shape[1] != w or frame.shape[0] != h:
                frame = cv2.resize(frame, (w, h))
            return frame

        return None

    def _grab_mss(self, monitor: dict, out_w: int, out_h: int):
        try:
            sct = self._screen_mss.grab(monitor)
            frame = np.array(sct)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
            if frame.shape[1] != out_w or frame.shape[0] != out_h:
                frame = cv2.resize(frame, (out_w, out_h))
            return frame
        except Exception as e:
            log.error(f"mss error: {e}")
            return None

    def _grab_window_win32(self, hwnd, out_w: int, out_h: int):
        try:
            import ctypes, ctypes.wintypes
            DWMWA_EXTENDED_FRAME_BOUNDS = 9
            rect = ctypes.wintypes.RECT()
            hr = ctypes.windll.dwmapi.DwmGetWindowAttribute(
                hwnd, DWMWA_EXTENDED_FRAME_BOUNDS,
                ctypes.byref(rect), ctypes.sizeof(rect)
            )
            if hr != 0:
                ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect))

            ww = rect.right - rect.left
            wh = rect.bottom - rect.top
            if ww <= 0 or wh <= 0:
                return None

            hwnd_dc = ctypes.windll.user32.GetDC(hwnd)
            mem_dc  = ctypes.windll.gdi32.CreateCompatibleDC(hwnd_dc)
            bitmap  = ctypes.windll.gdi32.CreateCompatibleBitmap(hwnd_dc, ww, wh)
            ctypes.windll.gdi32.SelectObject(mem_dc, bitmap)
            ctypes.windll.user32.PrintWindow(hwnd, mem_dc, 2)  # PW_RENDERFULLCONTENT

            class BIH(ctypes.Structure):
                _fields_ = [
                    ("biSize",          ctypes.c_uint32),
                    ("biWidth",         ctypes.c_int32),
                    ("biHeight",        ctypes.c_int32),
                    ("biPlanes",        ctypes.c_uint16),
                    ("biBitCount",      ctypes.c_uint16),
                    ("biCompression",   ctypes.c_uint32),
                    ("biSizeImage",     ctypes.c_uint32),
                    ("biXPelsPerMeter", ctypes.c_int32),
                    ("biYPelsPerMeter", ctypes.c_int32),
                    ("biClrUsed",       ctypes.c_uint32),
                    ("biClrImportant",  ctypes.c_uint32),
                ]

            bmi = BIH()
            bmi.biSize = ctypes.sizeof(BIH)
            bmi.biWidth = ww; bmi.biHeight = -wh
            bmi.biPlanes = 1; bmi.biBitCount = 32; bmi.biCompression = 0
            buf = (ctypes.c_char * (ww * wh * 4))()
            ctypes.windll.gdi32.GetDIBits(mem_dc, bitmap, 0, wh, buf, ctypes.byref(bmi), 0)
            ctypes.windll.gdi32.DeleteObject(bitmap)
            ctypes.windll.gdi32.DeleteDC(mem_dc)
            ctypes.windll.user32.ReleaseDC(hwnd, hwnd_dc)

            frame = np.frombuffer(buf, dtype=np.uint8).reshape((wh, ww, 4))
            frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
            if frame.shape[1] != out_w or frame.shape[0] != out_h:
                frame = cv2.resize(frame, (out_w, out_h))
            return frame
        except Exception as e:
            log.error(f"grab_window_win32: {e}")
            return None


class VideoWidget:
    """Convierte frames numpy BGR a QPixmap para PyQt6."""

    @staticmethod
    def frame_to_pixmap(frame_bgr):
        try:
            from PyQt6.QtGui import QImage, QPixmap
            h, w, ch = frame_bgr.shape
            img = QImage(
                frame_bgr.data, w, h, w * ch, QImage.Format.Format_BGR888
            )
            return QPixmap.fromImage(img)
        except Exception:
            return None
